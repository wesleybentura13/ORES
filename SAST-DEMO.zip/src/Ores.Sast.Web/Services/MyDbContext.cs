﻿using System.Data.Entity;


namespace Ores.Sast.Web.Services;

public class MyDbContext : DbContext
{

}