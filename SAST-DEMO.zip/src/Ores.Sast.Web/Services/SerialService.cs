﻿using System.Security.Policy;
using System.Xml.Linq;

namespace Ores.Sast.Web.Services;


public class SerialService
{
    public void VulnerableDeserialization(string serializedData)
    {
        var deserializedObject = System.Text.Json.JsonSerializer.Deserialize<object>(serializedData);
        // Utilisation de l'objet désérialisé
    }

    public void VulnerableXPathInjection(string userInput)
    {
        var query = $"SELECT * FROM table WHERE column = '{userInput}'";
        // Utilisation de la requête
    }

    public void VulnerableXXE(string xmlInput)
    {
        var xml = new System.Xml.XmlDocument();
        xml.LoadXml(xmlInput);
        // Utilisation du document XML
    }

    public void VulnerableXSLT(string xmlInput)
    {
        var xslt = new System.Xml.Xsl.XslCompiledTransform();
        xslt.Load(xmlInput);
        // Utilisation de la transformation XSLT
    }

    public void VulnerableRegex(string userInput)
    {
        var regex = new System.Text.RegularExpressions.Regex(userInput);
        // Utilisation de l'expression régulière
    }

    public void VulnerableCommandInjection(string command)
    {
        var process = new System.Diagnostics.Process();
        process.StartInfo.FileName = command;
        process.Start();
    }

    public void VulnerableLDAPInjection(string userInput)
    {
        var query = $"SELECT * FROM table WHERE column = '{userInput}'";
        // Utilisation de la requête
    }

    public void VulnerablePathTraversal(string userInput)
    {
        var path = userInput;
        // Utilisation du chemin
    }

    public void VulnerableFileUpload(string filePath)
    {
        var file = System.IO.File.ReadAllBytes(filePath);
        // Utilisation du fichier
    }

    public void VulnerableFileDownload(string filePath)
    {
        var file = System.IO.File.ReadAllBytes(filePath);
        // Utilisation du fichier
    }

    public string InsecureHashingFunction(string input)
    {
        var md5 = System.Security.Cryptography.MD5.Create();
        var inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
        var hash = md5.ComputeHash(inputBytes);
        return System.BitConverter.ToString(hash).Replace("-", "").ToLower();
    }


    // Example of CWE-540: Inclusion of Sensitive Information in Source Code
    public string InsecureLogging(string input)
    {
        System.Console.WriteLine("The user input is: " + input);
        return input;
    }

    // example of CWE-500: Public Static Field Not Marked Final
    public static string InsecureStatic
    {
        get
        {
            return "This is a static field";
        }
    }

    public static string InsecureHttp
    {
        get
        {
            return "http://insecure.com";
        }
    }

    public static string InsecureFtp
    {
        get
        {
            return "ftp://insecure.com";
        }

    }

    // Example of the following list of CWEs:
    //    BaseOut-of-bounds Write - (787)

    public void VulnerableOutOfBoundWrite(string[] array, int index, string value)
    {
        array[index] = value;
    }

    //*BaseImproper Neutralization of Input During Web Page Generation('Cross-site Scripting') - (79)

    public string VulnerableXSS(string input)
    {
        return "<div>" + input + "</div>";
    }

    //*BaseImproper Neutralization of Special Elements used in an SQL Command('SQL Injection') - (89)

    public void VulnerableSqlInjection(string userInput)
    {
        var query = $"SELECT * FROM table WHERE column = '{userInput}'";
        // Utilisation de la requête
    }

    //*VariantUse After Free - (416)

    public void VulnerableUseAfterFree()
    {
        var obj = new object();
        obj = null;
        // Utilisation de l'objet libéré
    }
    //*BaseImproper Neutralization of Special Elements used in an OS Command('OS Command Injection') - (78)

    public void VulnerableCommandInjection2(string command)
    {
        var process = new System.Diagnostics.Process();
        process.StartInfo.FileName = command;
        process.Start();
    }
    //*ClassImproper Input Validation - (20)

    public void VulnerableInputValidation(string input)
    {
        if (input == "admin")
        {
            // Utilisation de l'entrée
        }
    }
    //*BaseOut-of-bounds Read - (125)

    public string VulnerableOutOfBoundRead(string[] array, int index)
    {
        return array[index];
    }
    //*BaseImproper Limitation of a Pathname to a Restricted Directory('Path Traversal') - (22)

    public void VulnerablePathTraversal2(string userInput)
    {
        var path = userInput;
        // Utilisation du chemin
    }

    //*CompositeCross-Site Request Forgery(CSRF) - (352)

    public void VulnerableCSRF(string url)
    {
        var request = System.Net.WebRequest.Create(url);
        request.GetResponse();
    }

    //*BaseUnrestricted Upload of File with Dangerous Type - (434)

    public void VulnerableFileUpload2(string filePath)
    {
        var file = System.IO.File.ReadAllBytes(filePath);
        // Utilisation du fichier
    }

    //*ClassMissing Authorization - (862)

    public void VulnerableMissingAuthorization()
    {
        var identity = System.Security.Principal.WindowsIdentity.GetCurrent();
        if (identity.IsAuthenticated)
        {
            // Utilisation de l'identité
        }
    }

    //*BaseNULL Pointer Dereference - (476)

    public void VulnerableNullPointerDereference()
    {
        object obj = null;
        obj.ToString();
    }

    //*ClassImproper Authentication - (287)

    public void VulnerableAuthentication(string username, string password)
    {
        if (username == "admin" && password == "admin")
        {
            // Authentification réussie
        }
    }

    //*BaseInteger Overflow or Wraparound - (190)

    public int VulnerableIntegerOverflow(int a, int b)
    {
        return a + b;
    }
    //*BaseDeserialization of Untrusted Data - (502)

    public void VulnerableDeserialization2(string serializedData)
    {
        var deserializedObject = System.Text.Json.JsonSerializer.Deserialize<object>(serializedData);
        // Utilisation de l'objet désérialisé
    }
    //*ClassImproper Neutralization of Special Elements used in a Command('Command Injection') - (77)

    public void VulnerableCommandInjection3(string command)
    {
        var process = new System.Diagnostics.Process();
        process.StartInfo.FileName = command;
        process.Start();
    }
    //*ClassImproper Restriction of Operations within the Bounds of a Memory Buffer - (119)

    public void VulnerableMemoryBuffer(string input)
    {
        var buffer = new byte[10];
        System.Text.Encoding.ASCII.GetBytes(input, 0, input.Length, buffer, 0);
    }
    //*BaseUse of Hard-coded Credentials - (798)

    public void VulnerableHardcodedCredentials(string username, string password)
    {
        if (username == "admin" && password == "admin")
        {
            // Authentification réussie
        }
    }
    //*BaseServer-Side Request Forgery(SSRF) - (918)

    public void VulnerableSSRF(string url)
    {
        var request = System.Net.WebRequest.Create(url);
        request.GetResponse();
    }

    //*BaseMissing Authentication for Critical Function - (306)

    public void VulnerableMissingAuthentication()
    {
        var identity = System.Security.Principal.WindowsIdentity.GetCurrent();
        if (identity.IsAuthenticated)
        {
            // Utilisation de l'identité
        }
    }

    //*ClassConcurrent Execution using Shared Resource with Improper Synchronization('Race Condition') - (362)

    public void VulnerableRaceCondition()
    {
        var file = System.IO.File.ReadAllBytes("file.txt");
        // Utilisation du fichier
    }
    //* ClassImproper Privilege Management - (269)

    public void VulnerablePrivilegeManagement()
    {
        var identity = System.Security.Principal.WindowsIdentity.GetCurrent();
        if (identity.IsAuthenticated)
        {
            // Utilisation de l'identité
        }
    }
    //* BaseImproper Control of Generation of Code('Code Injection') - (94)

    public void VulnerableCodeInjection(string code)
    {
        System.CodeDom.Compiler.CodeDomProvider.CreateProvider("CSharp").CompileAssemblyFromSource(new System.CodeDom.Compiler.CompilerParameters(), code);
    }

    //* ClassIncorrect Authorization - (863)

    public void VulnerableIncorrectAuthorization()
    {
        var identity = System.Security.Principal.WindowsIdentity.GetCurrent();
        if (identity.IsAuthenticated)
        {
            // Utilisation de l'identité
        }
    }
    //* BaseIncorrect Default Permissions - (276)

    public void VulnerableDefaultPermissions()
    {
        var file = System.IO.File.ReadAllBytes("file.txt");
        // Utilisation du fichier
    }
}
