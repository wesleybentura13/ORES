﻿using Microsoft.Data.SqlClient;


namespace Ores.Sast.Web.Services;

public class SqlService
{
    public void VulnerableSqlInjection(string userInput)
    {
        var query = $"SELECT * FROM table WHERE column = '{userInput}'";
        
        using (var connection = new SqlConnection("connectionString"))
        {
            connection.Open();
            using (var command = new SqlCommand(query, connection))
            {
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Console.WriteLine(reader.GetString(0));
                    }
                }
            }
        }
    }

    public void StorePasswordUser(string password)
    {
        var query = $"UPDATE USER  * FROM table WHERE column = '{password}'";
     
        using (var connection = new SqlConnection("User ID=root;Password=myPlmmkljlmkjvfvassword;Host=localhost;Port=5432;Database=myDataBase;Pooling=true;Min Pool Size=0;Max Pool Size=100;Connection Lifetime=0;"))
        {
            connection.Open();
            using (var command = new SqlCommand(query, connection))
            {
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Console.WriteLine(reader.GetString(0));
                    }
                }
            }
        }
    }
}
