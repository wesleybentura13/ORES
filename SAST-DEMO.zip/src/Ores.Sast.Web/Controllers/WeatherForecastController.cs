using Microsoft.AspNetCore.Mvc;
using Ores.Sast.Web.Services;

namespace Ores.Sast.Web.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        private readonly ILogger<WeatherForecastController> _logger;

        public WeatherForecastController(ILogger<WeatherForecastController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public IEnumerable<WeatherForecast> Get()
        {
            return Enumerable.Range(1, 5).Select(index => new WeatherForecast
            {
                Date = DateOnly.FromDateTime(DateTime.Now.AddDays(index)),
                TemperatureC = Random.Shared.Next(-20, 55),
                Summary = Summaries[Random.Shared.Next(Summaries.Length)]
            })
            .ToArray();

            throw new Exception("This is a test exception");
        }




        [HttpPost]
        public string Post([FromBody] string content)
        {

            return $"<div>{content}</div>";
        }

        [HttpGet]
        public bool Get([FromQuery] string username, string password )
        {
            using var context = new MyDbContext();
            string sql = "SELECT * FROM Users WHERE UserName='" + username + "' AND Password='"
                + password + "'";
            context.Database.ExecuteSqlCommand(sql);

            return true;
        }

    }
}
